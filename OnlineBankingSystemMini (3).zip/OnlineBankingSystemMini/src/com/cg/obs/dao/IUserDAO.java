package com.cg.obs.dao;

import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;

public interface IUserDAO
{
	public Users getUser(String id) throws UserException;
	public Admin getAdmin(String id) throws UserException;
}
